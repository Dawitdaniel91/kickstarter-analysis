# Kickstarting with Excel

## Overview of Project:In this project, Louise wants to start croed funding project with estimated about $10000 budget.She wants to now how diffrent campigns fared n relation to thier launch dates and thier funding goals.I am helping her by using the kickstarter dataset that have already combed through, I 'll visualize campaign outcomes based on thier lauch dates and thier funding goals.

### Purpose:to analyze and visualize campaign outcomes based on launch dates and funding goals.

## Analysis and Challenges:I started with dataset of kickstarter 4114 projects, and created additional future included new column "Data create conversion" and "years". The "Catagory and subcategory" and "subcatagory" futre was divided into tow separate columns is called "Parent Catagory" and "subcatagory" for more accurate detailed analysis.The challenges were using the right formulas to get the required data, and preparing the proper chart based on charts on the infrormation.

### Analysis of Outcomes Based on Launch Date:The data analysis was based on twelve months of the year in which the project theater was conducted, and the outcome on launch date. Based on a graph "theater_Outcomes_vs_Laucnh", the data shows that the project on a theater are significantly succeeded from january to june of the year when comparing with the rest of the month. Specially, the month of May has the higest succesful out come, but the month of December has the least outcome in the year.

### Analysis of Outcomes Based on Goals:Bases on the graph "Outcomes_vs_Goal", the data shows that the project goal funding money inceases when the percentage of succced an outcome number decreases.The highest percentage(76%) of succeeded outcome is the lowest project funding goal(less than $1000).But the results shows that change of percentage(17%)seceeded number of outcome after Zero(0%) perecent of succeeded outcome.

### Challenges and Difficulties Encountered:one of the challenges was using some formula on the Excel sheet.But after precticing and trying the formula on the Excel cells finally i get the required results. The other challenge was using the best chart to explain more the visuluse result of the outcome.But after trying different possible options of chart finally I chose the best chart which can better vissulize the outcome results.

## Results

Conclussion :The results of Analysis of outcomes based on Launch Data shows that, May and June are the best months in the year  to conduct the theather project, Whereas November and December are the worest months to laucnh the theather project in the year.The results for other data analysis ,"outcomes vs goal", shows that the  theater project with smalles goal is the most succesful than the theater project with hihest goals.

Limitation: The scope of data analysis is based on the two data which are the Launch data and goal.Other data are not included in the analysis that may be infuluse the success of theater project, like geographical considration, duration of the project, amount of pledge, baker and average donatin which could be conducted to make further analysis in the project to make better conclussion.

Possible tables and/or graphs:The data analysis could give us better conclussion if we use some possible data as the tables or graphs from Kichstater dataset. Such as it could be better if you use saff pick and pludge amunts as graph in the launch date analysi.It could be possible to use The Avarage of donation, backer,duration of the project in the table of the project abalysis.
